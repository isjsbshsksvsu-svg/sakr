plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.sakr.arabicwordformatter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sakr.arabicwordformatter"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // MultiDex ضروري لأن Apache POI ضخم ويتجاوز 64K method
        multiDexEnabled = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    // IMPORTANT: POI و xmlbeans فيهم ملفات javax.xml بتتضارب مع Android
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/INDEX.LIST",
                "META-INF/services/org.apache.xmlbeans.impl.schema.SchemaTypeSystemLoader",
                "META-INF/services/org.apache.xmlbeans.impl.schema.SchemaTypeLoader",
                "META-INF/services/org.apache.xmlbeans.impl.xpath.XPathEngine",
                "javax/xml/namespace/QName.class",
                "javax/xml/stream/XMLInputFactory.class",
                "javax/xml/stream/XMLOutputFactory.class",
                "javax/xml/stream/XMLEventFactory.class",
                "javax/xml/stream/events/*"
            )
        }
    }
}

dependencies {
    // Android Core
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // MultiDex
    implementation("androidx.multidex:multidex:2.0.1")

    // Navigation
    implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
    implementation("androidx.navigation:navigation-ui-ktx:2.7.7")

    // Lifecycle + ViewModel
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.3")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.3")
    implementation("androidx.activity:activity-ktx:1.9.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // Apache POI for DOCX generation - إصدار متوافق مع Android
    implementation("org.apache.poi:poi-ooxml:5.2.5") {
        exclude("javax.xml.stream", "stax-api")
        exclude("xml-apis", "xml-apis")
    }
    implementation("org.apache.poi:poi:5.2.5")
    implementation("org.apache.xmlbeans:xmlbeans:5.1.1")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
