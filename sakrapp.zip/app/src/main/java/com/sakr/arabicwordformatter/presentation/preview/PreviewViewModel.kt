package com.sakr.arabicwordformatter.presentation.preview

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.sakr.arabicwordformatter.domain.model.DocumentBlock
import com.sakr.arabicwordformatter.domain.model.ParsedDocument
import com.sakr.arabicwordformatter.domain.usecase.GenerateDocxUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PreviewViewModel(application: Application) : AndroidViewModel(application) {
    private val generateDocxUseCase = GenerateDocxUseCase()

    private val _document = MutableLiveData<ParsedDocument?>()
    val document: LiveData<ParsedDocument?> = _document

    private val _blocks = MutableLiveData<List<DocumentBlock>>(emptyList())
    val blocks: LiveData<List<DocumentBlock>> = _blocks

    private val _isGenerating = MutableLiveData(false)
    val isGenerating: LiveData<Boolean> = _isGenerating

    private val _generatedUri = MutableLiveData<Uri?>()
    val generatedUri: LiveData<Uri?> = _generatedUri

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    private val _fileName = MutableLiveData("مستند_سكر")
    val fileName: LiveData<String> = _fileName

    fun loadDocument(doc: ParsedDocument) {
        _document.value = doc
        _blocks.value = doc.blocks.toMutableList()
        _fileName.value = doc.title ?: "مستند_سكر"
    }

    fun updateBlock(index: Int, newBlock: DocumentBlock) {
        val currentBlocks = _blocks.value?.toMutableList() ?: return
        if (index in currentBlocks.indices) {
            currentBlocks[index] = newBlock
            _blocks.value = currentBlocks
        }
    }

    fun deleteBlock(index: Int) {
        val currentBlocks = _blocks.value?.toMutableList() ?: return
        if (index in currentBlocks.indices) {
            currentBlocks.removeAt(index)
            _blocks.value = currentBlocks
        }
    }

    fun moveBlock(fromIndex: Int, toIndex: Int) {
        val currentBlocks = _blocks.value?.toMutableList() ?: return
        if (fromIndex in currentBlocks.indices && toIndex in currentBlocks.indices) {
            val item = currentBlocks.removeAt(fromIndex)
            currentBlocks.add(toIndex, item)
            _blocks.value = currentBlocks
        }
    }

    fun mergeBlocks(index: Int) {
        val currentBlocks = _blocks.value?.toMutableList() ?: return
        if (index <= 0 || index >= currentBlocks.size) return

        val previous = currentBlocks[index - 1]
        val current = currentBlocks[index]

        if (previous is DocumentBlock.Paragraph && current is DocumentBlock.Paragraph) {
            val merged = DocumentBlock.Paragraph(previous.text + "\n" + current.text)
            currentBlocks[index - 1] = merged
            currentBlocks.removeAt(index)
            _blocks.value = currentBlocks
        }
    }

    fun setFileName(name: String) {
        _fileName.value = name
    }

    fun generateDocx() {
        val blocks = _blocks.value ?: return
        val title = _fileName.value ?: "مستند_سكر"
        if (blocks.isEmpty()) {
            _error.value = "لا توجد كتل لتصديرها"
            return
        }

        _isGenerating.value = true
        _error.value = null

        val document = ParsedDocument(
            blocks = blocks,
            title = title,
            rawText = ""
        )

        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                generateDocxUseCase(getApplication(), document, title)
            }
            result.fold(
                onSuccess = { uri ->
                    _generatedUri.value = uri
                    _isGenerating.value = false
                },
                onFailure = { e ->
                    _error.value = "فشل التوليد: ${e.localizedMessage}"
                    _isGenerating.value = false
                }
            )
        }
    }

    fun clearError() {
        _error.value = null
    }
}
