package com.sakr.arabicwordformatter.core.parser

object PatternRules {
    // Arabic ordinal indicators (أولاً, ثانياً, etc.)
    val ARABIC_ORDINALS = listOf(
        "أولاً", "ثانياً", "ثالثاً", "رابعاً", "خامساً",
        "سادساً", "سابعاً", "ثامناً", "تاسعاً", "عاشراً"
    )

    // Comparison keywords
    val COMPARISON_KEYWORDS = listOf(
        "الفرق بين", "مقارنة", "المقارنة بين", "مقارنة بين",
        "الفرق", "أوجه التشابه والاختلاف", "قارن بين"
    )

    // Definition keywords
    val DEFINITION_KEYWORDS = listOf(
        "هو", "هي", "تعني", "يعني", "تعريف",
        "يقصد به", "يقصد بها", "تعرف بأنها", "يعرف بأنه"
    )

    // Scientific number pattern (Latin digits in scientific context)
    val SCIENTIFIC_NUMBER = Regex("[0-9]+(\\.[0-9]+)?([%°CcFf]|%)?")

    // Arabic number pattern
    val ARABIC_NUMBER = Regex("[٠١٢٣٤٥٦٧٨٩]+")

    // Bullet point patterns
    val BULLET_PATTERN = Regex("^[-•*▪➢→]\\s*")

    // Numbered list pattern (Arabic or Latin)
    val NUMBERED_PATTERN = Regex("^[\\d٠١٢٣٤٥٦٧٨٩]+[.)]\\s*")

    // Subheading with colon
    val COLON_SUBHEADING = Regex("^.+:\\s*$")

    // Short heading detection - lines that look like headings
    val SHORT_HEADING_THRESHOLD = 50
}
