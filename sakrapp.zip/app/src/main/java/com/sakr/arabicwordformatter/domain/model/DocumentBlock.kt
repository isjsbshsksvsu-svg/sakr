package com.sakr.arabicwordformatter.domain.model

import java.io.Serializable

sealed class DocumentBlock : Serializable {
    data class MainHeading(val text: String) : DocumentBlock()
    data class SubHeading(val text: String) : DocumentBlock()
    data class Paragraph(val text: String) : DocumentBlock()
    data class BulletList(val items: List<String>) : DocumentBlock()
    data class NumberedList(val items: List<String>) : DocumentBlock()
    data class ComparisonTable(
        val headers: List<String>,
        val rows: List<List<String>>,
        val rowCount: Int
    ) : DocumentBlock()
    data class Definition(val term: String, val meaning: String) : DocumentBlock()

    fun toEditableText(): String {
        return when (this) {
            is MainHeading -> text
            is SubHeading -> text
            is Paragraph -> text
            is BulletList -> items.joinToString("\n") { "- $it" }
            is NumberedList -> items.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
            is ComparisonTable -> {
                val sb = StringBuilder()
                if (headers.isNotEmpty()) {
                    sb.appendLine(headers.joinToString(" | "))
                    sb.appendLine(headers.joinToString(" | ") { "---" })
                }
                rows.forEach { row ->
                    sb.appendLine(row.joinToString(" | "))
                }
                sb.toString()
            }
            is Definition -> "$term: $meaning"
        }
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
