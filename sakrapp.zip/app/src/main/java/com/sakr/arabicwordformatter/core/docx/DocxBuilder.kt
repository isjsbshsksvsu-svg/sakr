package com.sakr.arabicwordformatter.core.docx

import com.sakr.arabicwordformatter.domain.model.DocumentBlock
import com.sakr.arabicwordformatter.domain.model.ParsedDocument
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFTable
import org.apache.poi.xwpf.usermodel.XWPFTableRow
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth
import java.math.BigInteger

class DocxBuilder {

    fun build(document: ParsedDocument): XWPFDocument {
        val doc = XWPFDocument()
        RtlFormatter.configureDocument(doc)

        // Document title
        val title = document.title ?: "مستند سكر"
        addTitle(doc, title)
        addEmptyLine(doc)

        for (block in document.blocks) {
            when (block) {
                is DocumentBlock.MainHeading -> addHeading(doc, block.text, 1)
                is DocumentBlock.SubHeading -> addHeading(doc, block.text, 2)
                is DocumentBlock.Paragraph -> addParagraph(doc, block.text)
                is DocumentBlock.BulletList -> addBulletList(doc, block.items)
                is DocumentBlock.NumberedList -> addNumberedList(doc, block.items)
                is DocumentBlock.ComparisonTable -> buildTable(doc, block)
                is DocumentBlock.Definition -> addDefinition(doc, block.term, block.meaning)
            }
        }

        return doc
    }

    private fun addTitle(doc: XWPFDocument, title: String) {
        val para = doc.createParagraph()
        RtlFormatter.applyRTL(para)
        val pPr = para.ctp.pPr ?: para.ctp.addNewPPr()
        pPr.addNewKeepNext()

        val run = para.createRun()
        run.setText(title)
        RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_TITLE, bold = true)

        // Center alignment for title
        val jc = pPr.addNewJc()
        jc.`val` = org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc.CENTER
    }

    fun addHeading(doc: XWPFDocument, text: String, level: Int) {
        val para = doc.createParagraph()
        RtlFormatter.applyRTL(para)
        val pPr = para.ctp.pPr ?: para.ctp.addNewPPr()
        pPr.addNewKeepNext()
        pPr.addNewKeepLines()
        pPr.addNewOutlineLvl().`val` = BigInteger.valueOf((level - 1).toLong())

        val run = para.createRun()
        run.setText(text)
        when (level) {
            1 -> RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_H1, bold = true)
            2 -> RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_H2, bold = true)
        }
    }

    private fun addParagraph(doc: XWPFDocument, text: String) {
        val para = doc.createParagraph()
        RtlFormatter.applyRTL(para)

        val run = para.createRun()
        run.setText(text)
        RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_BODY)
        para.setSpacingAfter(200)
    }

    private fun addBulletList(doc: XWPFDocument, items: List<String>) {
        for (item in items) {
            val para = doc.createParagraph()
            RtlFormatter.applyRTL(para)
            val pPr = para.ctp.pPr ?: para.ctp.addNewPPr()
            pPr.addNewInd().apply {
                left = BigInteger.valueOf(720L)
                right = BigInteger.valueOf(-720L)
            }

            val run = para.createRun()
            run.setText("• $item")
            RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_BODY)
            para.setSpacingAfter(100)
        }
    }

    private fun addNumberedList(doc: XWPFDocument, items: List<String>) {
        items.forEachIndexed { index, item ->
            val para = doc.createParagraph()
            RtlFormatter.applyRTL(para)
            val pPr = para.ctp.pPr ?: para.ctp.addNewPPr()
            pPr.addNewInd().apply {
                left = BigInteger.valueOf(720L)
                right = BigInteger.valueOf(-720L)
            }

            val run = para.createRun()
            run.setText("${index + 1}. $item")
            RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_BODY)
            para.setSpacingAfter(100)
        }
    }

    private fun addDefinition(doc: XWPFDocument, term: String, meaning: String) {
        val para = doc.createParagraph()
        RtlFormatter.applyRTL(para)

        val runTerm = para.createRun()
        runTerm.setText("$term: ")
        RtlFormatter.applyFont(runTerm, StyleConstants.FONT_SIZE_BODY, bold = true)

        val runMeaning = para.createRun()
        runMeaning.setText(meaning)
        RtlFormatter.applyFont(runMeaning, StyleConstants.FONT_SIZE_BODY)

        para.setSpacingAfter(200)
    }

    fun buildTable(doc: XWPFDocument, table: DocumentBlock.ComparisonTable) {
        val rowCount = table.rows.size
        val colCount = table.headers.size.coerceAtLeast(
            table.rows.maxOfOrNull { it.size } ?: 0
        )
        if (rowCount == 0 || colCount == 0) return

        val xwpfTable = doc.createTable(rowCount + 1, colCount)

        // Disable autofit, set fixed width
        xwpfTable.ctTbl.addNewTblPr().addNewTblW().apply {
            type = STTblWidth.DXA
            w = BigInteger.valueOf(StyleConstants.MAX_TABLE_WIDTH_TWIPS.toLong())
        }

        // Set table borders
        val tblBorders = xwpfTable.ctTbl.addNewTblPr().addNewTblBorders()
        for (border in listOf(
            tblBorders.addNewTop(), tblBorders.addNewBottom(),
            tblBorders.addNewLeft(), tblBorders.addNewRight(),
            tblBorders.addNewInsideH(), tblBorders.addNewInsideV()
        )) {
            border.`val` = org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder.SINGLE
            border.sz = BigInteger.valueOf(4L)
            border.color = "000000"
        }

        val colWidth = StyleConstants.MAX_TABLE_WIDTH_TWIPS / colCount

        // Header row
        val headerRow = xwpfTable.getRow(0)
        val trPr = headerRow.ctRow.addNewTrPr()
        trPr.addNewCantSplit()
        table.headers.forEachIndexed { colIdx, header ->
            val cell = headerRow.getCell(colIdx)
            cell.setWidth(colWidth.toString())
            RtlFormatter.setTableCellRTL(cell)
            val para = cell.getParagraph(0)
            val run = para.createRun()
            run.setText(header)
            RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_TABLE, bold = true)
            // Shade header
            val tcPr = cell.ctTc.addNewTcPr()
            tcPr.addNewShd().apply {
                fill = "D9E2F3"
                `val` = org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd.CLEAR
            }
        }

        // Data rows
        table.rows.forEachIndexed { rowIdx, row ->
            val xwpfRow = xwpfTable.getRow(rowIdx + 1)
            val rowTrPr = xwpfRow.ctRow.addNewTrPr()
            rowTrPr.addNewCantSplit()

            for (colIdx in 0 until colCount) {
                val cell = xwpfRow.getCell(colIdx)
                cell.setWidth(colWidth.toString())
                RtlFormatter.setTableCellRTL(cell)
                val para = cell.getParagraph(0)
                val run = para.createRun()
                run.setText(row.getOrElse(colIdx) { "" })
                RtlFormatter.applyFont(run, StyleConstants.FONT_SIZE_TABLE)
            }
        }

        // Add spacing after table
        val spacer = doc.createParagraph()
        spacer.setSpacingAfter(200)
    }

    fun addEmptyLine(doc: XWPFDocument) {
        val para = doc.createParagraph()
        para.setSpacingAfter(100)
    }
}
