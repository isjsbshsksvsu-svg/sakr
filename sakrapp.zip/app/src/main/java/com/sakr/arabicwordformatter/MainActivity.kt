package com.sakr.arabicwordformatter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.sakr.arabicwordformatter.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // معالجة النص المستلم من تطبيق آخر (مشاركة)
        handleSharedText(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedText(intent)
    }

    private fun handleSharedText(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                // تمرير النص إلى InputFragment عبر Bundle
                val navHostFragment = supportFragmentManager
                    .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
                val navController = navHostFragment.navController

                // انتظار حتى يتم تحميل الـ Fragment
                navController.addOnDestinationChangedListener { _, destination, _ ->
                    if (destination.id == R.id.inputFragment) {
                        val inputFragment = navHostFragment.childFragmentManager
                            .fragments.firstOrNull() as? com.sakr.arabicwordformatter.presentation.input.InputFragment
                        inputFragment?.setReceivedText(sharedText)
                    }
                }
            }
        }
    }
}
