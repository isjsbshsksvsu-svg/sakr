package com.sakr.arabicwordformatter.core.utils

object ArabicNumerals {

    private val arabicToLatin = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9'
    )

    private val latinToArabic = mapOf(
        '0' to '٠', '1' to '١', '2' to '٢', '3' to '٣', '4' to '٤',
        '5' to '٥', '6' to '٦', '7' to '٧', '8' to '٨', '9' to '٩'
    )

    fun toArabicNumerals(text: String): String {
        return text.map { latinToArabic[it] ?: it }.joinToString("")
    }

    fun toLatinNumerals(text: String): String {
        return text.map { arabicToLatin[it] ?: it }.joinToString("")
    }

    fun isScientificContext(text: String): Boolean {
        val scientificPattern = Regex("""[\d.]+([%°CcFf]|%)""")
        return scientificPattern.containsMatchIn(text)
    }
}
