package com.sakr.arabicwordformatter.presentation.input

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.sakr.arabicwordformatter.R
import com.sakr.arabicwordformatter.SakrApplication
import com.sakr.arabicwordformatter.core.utils.ArabicNumerals
import com.sakr.arabicwordformatter.core.utils.ClipboardHelper
import com.sakr.arabicwordformatter.core.utils.DocumentTemplates
import com.sakr.arabicwordformatter.databinding.FragmentInputBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class InputFragment : Fragment() {
    private var _binding: FragmentInputBinding? = null
    private val binding get() = _binding!!
    private val viewModel: InputViewModel by viewModels()
    private var pendingSharedText: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
        updateStats("")

        pendingSharedText?.let { text ->
            binding.editText.setText(text)
            binding.editText.setSelection(text.length)
            viewModel.setText(text)
            pendingSharedText = null
            Snackbar.make(binding.root, R.string.text_shared_from, Snackbar.LENGTH_SHORT).show()
        }
    }

    fun setReceivedText(text: String) {
        if (isResumed) {
            binding.editText.setText(text)
            binding.editText.setSelection(text.length)
            viewModel.setText(text)
            Snackbar.make(binding.root, R.string.text_shared_from, Snackbar.LENGTH_SHORT).show()
        } else {
            pendingSharedText = text
        }
    }

    private fun setupUI() {
        binding.toolbar.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.action_drafts -> {
                    findNavController().navigate(R.id.action_input_to_drafts)
                    true
                }
                R.id.action_templates -> {
                    showTemplatePicker()
                    true
                }
                else -> false
            }
        }

        binding.btnAnalyze.setOnClickListener { viewModel.parseText() }

        binding.btnPaste.setOnClickListener {
            val text = ClipboardHelper.getFromClipboard(requireContext())
            if (text != null) {
                binding.editText.setText(text)
                binding.editText.setSelection(text.length)
                viewModel.setText(text)
                Snackbar.make(binding.root, "تم اللصق من الحافظة", Snackbar.LENGTH_SHORT).show()
            } else {
                Snackbar.make(binding.root, "لا يوجد نص في الحافظة", Snackbar.LENGTH_SHORT).show()
            }
        }

        binding.btnClear.setOnClickListener {
            binding.editText.text?.clear()
            viewModel.setText("")
        }

        binding.btnSaveDraft.setOnClickListener {
            val text = binding.editText.text?.toString()
            if (!text.isNullOrBlank()) {
                saveDraft(text, "draft")
            } else {
                Snackbar.make(binding.root, R.string.error_empty, Snackbar.LENGTH_SHORT).show()
            }
        }

        binding.btnConvertNumerals.setOnClickListener {
            val text = binding.editText.text?.toString()
            if (!text.isNullOrBlank()) {
                val converted = ArabicNumerals.toArabicNumerals(text)
                binding.editText.setText(converted)
                binding.editText.setSelection(converted.length)
                viewModel.setText(converted)
                Snackbar.make(binding.root, R.string.numerals_converted, Snackbar.LENGTH_SHORT).show()
            }
        }

        binding.editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s?.toString() ?: ""
                viewModel.setText(text)
                updateStats(text)
            }
        })
    }

    private fun showTemplatePicker() {
        val templates = DocumentTemplates.allTemplates
        val titles = templates.map { it.title }.toTypedArray()

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("اختر قالباً")
            .setItems(titles) { _, which ->
                val template = templates[which]
                binding.editText.setText(template.content)
                binding.editText.setSelection(template.content.length)
                viewModel.setText(template.content)
                Snackbar.make(binding.root, "تم تحميل قالب: ${template.title}", Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun updateStats(text: String) {
        val charCount = text.length
        val wordCount = if (text.isBlank()) 0 else text.trim().split("\\s+".toRegex()).size
        binding.textCharCount.text = "$charCount حرف"
        binding.textWordCount.text = "$wordCount كلمة"
    }

    private fun saveDraft(text: String, type: String) {
        val title = text.lines().firstOrNull()?.take(50)?.trim() ?: "مسودة"
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val app = requireActivity().application as SakrApplication
                withContext(Dispatchers.IO) {
                    app.draftRepository.saveDraft(title, text, type)
                }
                val msg = if (type == "template") R.string.template_saved else R.string.draft_saved
                Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Snackbar.make(binding.root, "فشل الحفظ: ${e.localizedMessage}", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.isProcessing.observe(viewLifecycleOwner) { processing ->
            binding.progressBar.visibility = if (processing) View.VISIBLE else View.GONE
            binding.btnAnalyze.isEnabled = !processing
            binding.btnAnalyze.text = if (processing) "جارٍ المعالجة…" else "تحليل وتنسيق"
        }

        viewModel.parsedDocument.observe(viewLifecycleOwner) { document ->
            if (document != null && document.blocks.isNotEmpty()) {
                val bundle = Bundle().apply {
                    putSerializable("parsed_document", document)
                }
                findNavController().navigate(
                    R.id.action_input_to_preview, bundle
                )
                viewModel.clearError()
            }
        }

        viewModel.error.observe(viewLifecycleOwner) { errorMsg ->
            errorMsg?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
