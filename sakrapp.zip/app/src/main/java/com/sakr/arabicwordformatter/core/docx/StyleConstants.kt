package com.sakr.arabicwordformatter.core.docx

object StyleConstants {
    const val FONT_ARABIC = "Simplified Arabic"
    const val FONT_SIZE_TITLE = 18
    const val FONT_SIZE_H1 = 16
    const val FONT_SIZE_H2 = 14
    const val FONT_SIZE_BODY = 12
    const val FONT_SIZE_TABLE = 11
    const val PAGE_WIDTH_TWIPS = 12240
    const val PAGE_HEIGHT_TWIPS = 15840
    const val MARGIN_TWIPS = 1440
    const val MAX_TABLE_WIDTH_TWIPS = 9360
}
