package com.sakr.arabicwordformatter.core.docx

import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFParagraph
import org.apache.poi.xwpf.usermodel.XWPFRun
import org.apache.poi.xwpf.usermodel.XWPFTable
import org.apache.poi.xwpf.usermodel.XWPFTableCell
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRPr
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STOnOff
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc
import java.math.BigInteger

object RtlFormatter {

    fun applyRTL(paragraph: XWPFParagraph) {
        val pPr = paragraph.ctp.addNewPPr()
        val bidi = pPr.addNewBidi()
        bidi.`val` = STOnOff.ON
        val jc = pPr.addNewJc()
        jc.`val` = STJc.RIGHT
        pPr.addNewKeepNext()
        pPr.addNewKeepLines()
    }

    fun applyFont(run: XWPFRun, size: Int, bold: Boolean = false) {
        run.fontFamily = StyleConstants.FONT_ARABIC
        run.fontSize = size
        run.isBold = bold
        val rPr = run.ctr.addNewRPr()
        val rtl = rPr.addNewRtl()
        rtl.`val` = STOnOff.ON
    }

    fun configureDocument(doc: XWPFDocument) {
        val ctDoc = doc.document
        val body = ctDoc.body
        if (body.sectPr == null) body.addNewSectPr()
        val sectPr = body.sectPr

        val pgSz = sectPr.addNewPgSz()
        pgSz.w = BigInteger.valueOf(StyleConstants.PAGE_WIDTH_TWIPS.toLong())
        pgSz.h = BigInteger.valueOf(StyleConstants.PAGE_HEIGHT_TWIPS.toLong())

        val pgMar = sectPr.addNewPgMar()
        pgMar.top = BigInteger.valueOf(StyleConstants.MARGIN_TWIPS.toLong())
        pgMar.bottom = BigInteger.valueOf(StyleConstants.MARGIN_TWIPS.toLong())
        pgMar.left = BigInteger.valueOf(StyleConstants.MARGIN_TWIPS.toLong())
        pgMar.right = BigInteger.valueOf(StyleConstants.MARGIN_TWIPS.toLong())
        pgMar.header = BigInteger.valueOf(720L)
        pgMar.footer = BigInteger.valueOf(720L)
    }

    fun setTableCellRTL(cell: XWPFTableCell) {
        for (para in cell.paragraphs) {
            applyRTL(para)
        }
    }

    fun setTableRTL(table: XWPFTable) {
        for (row in table.rows) {
            for (cell in row.tableCells) {
                setTableCellRTL(cell)
            }
        }
    }
}
