package com.sakr.arabicwordformatter.presentation.preview

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.sakr.arabicwordformatter.R
import com.sakr.arabicwordformatter.SakrApplication
import com.sakr.arabicwordformatter.databinding.FragmentPreviewBinding
import com.sakr.arabicwordformatter.domain.model.ParsedDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PreviewFragment : Fragment() {
    private var _binding: FragmentPreviewBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PreviewViewModel by viewModels()
    private lateinit var adapter: BlockAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupRecyclerView()
        observeViewModel()

        val document = arguments?.getSerializable("parsed_document") as? ParsedDocument
        if (document != null) {
            viewModel.loadDocument(document)
        }

        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() { showExitConfirmDialog() }
            }
        )
    }

    private fun setupUI() {
        binding.btnGenerate.setOnClickListener {
            val fileName = binding.editFileName.text?.toString()
                ?.ifBlank { "مستند_سكر" } ?: "مستند_سكر"
            viewModel.setFileName(fileName)
            viewModel.generateDocx()
        }

        binding.btnBack.setOnClickListener { showExitConfirmDialog() }

        binding.btnSaveTemplate.setOnClickListener {
            saveCurrentAsTemplate()
        }
    }

    private fun setupRecyclerView() {
        adapter = BlockAdapter(
            onBlockChanged = { pos, block -> viewModel.updateBlock(pos, block) },
            onDeleteBlock = { pos ->
                viewModel.deleteBlock(pos)
                Snackbar.make(binding.root, "تم حذف الكتلة", Snackbar.LENGTH_SHORT).show()
            },
            onMergeBlock = { pos -> viewModel.mergeBlocks(pos) }
        )

        binding.recyclerBlocks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerBlocks.adapter = adapter

        val touchCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                viewModel.moveBlock(viewHolder.adapterPosition, target.adapterPosition)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
        }
        ItemTouchHelper(touchCallback).attachToRecyclerView(binding.recyclerBlocks)
    }

    private fun observeViewModel() {
        viewModel.blocks.observe(viewLifecycleOwner) { blocks ->
            adapter.submitList(blocks)
            binding.textBlockCount.text = "${blocks.size} كتل"
        }

        viewModel.isGenerating.observe(viewLifecycleOwner) { generating ->
            binding.progressBar.visibility = if (generating) View.VISIBLE else View.GONE
            binding.btnGenerate.isEnabled = !generating
            binding.btnGenerate.text = if (generating) "جارٍ التوليد…" else getString(R.string.btn_generate)
        }

        viewModel.generatedUri.observe(viewLifecycleOwner) { uri ->
            uri?.let { showFileSavedDialog(it) }
        }

        viewModel.error.observe(viewLifecycleOwner) { errorMsg ->
            errorMsg?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearError()
            }
        }

        viewModel.fileName.observe(viewLifecycleOwner) { name ->
            if (binding.editFileName.text?.toString().isNullOrBlank()) {
                binding.editFileName.setText(name)
            }
        }
    }

    private fun saveCurrentAsTemplate() {
        val blocks = viewModel.blocks.value ?: return
        val rawText = blocks.joinToString("\n\n") { it.toEditableText() }
        val title = (binding.editFileName.text?.toString() ?: "قالب") + " (قالب)"

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val app = requireActivity().application as SakrApplication
                withContext(Dispatchers.IO) {
                    app.draftRepository.saveDraft(title, rawText, "template")
                }
                Snackbar.make(binding.root, R.string.template_saved, Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Snackbar.make(binding.root, "فشل الحفظ", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun showFileSavedDialog(uri: android.net.Uri) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("✅ تم الحفظ بنجاح")
            .setMessage("تم توليد ملف Word منسق بالكامل بخط عربي واتجاه RTL")
            .setPositiveButton("📂 فتح الملف") { _, _ ->
                try {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(
                            uri,
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Snackbar.make(binding.root, "لا يمكن فتح الملف", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("📤 مشاركة") { _, _ ->
                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(intent, "مشاركة الملف"))
                } catch (e: Exception) {
                    Snackbar.make(binding.root, "لا يمكن مشاركة الملف", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("🔙 رجوع", null)
            .show()
    }

    private fun showExitConfirmDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("تأكيد الرجوع")
            .setMessage("سيتم فقدان التعديلات إن وجدت.")
            .setPositiveButton("💾 حفظ مسودة") { _, _ ->
                saveDraft()
                findNavController().navigateUp()
            }
            .setNegativeButton("تجاهل") { _, _ ->
                findNavController().navigateUp()
            }
            .setNeutralButton("إلغاء", null)
            .show()
    }

    private fun saveDraft() {
        val blocks = viewModel.blocks.value ?: return
        val rawText = blocks.joinToString("\n\n") { it.toEditableText() }
        val title = binding.editFileName.text?.toString() ?: "مسودة"

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val app = requireActivity().application as SakrApplication
                withContext(Dispatchers.IO) {
                    app.draftRepository.saveDraft(title, rawText, "draft")
                }
                Snackbar.make(binding.root, R.string.draft_saved, Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Snackbar.make(binding.root, "فشل الحفظ", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
