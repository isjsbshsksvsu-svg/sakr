package com.sakr.arabicwordformatter.presentation.drafts

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.sakr.arabicwordformatter.R
import com.sakr.arabicwordformatter.data.db.DraftEntity
import com.sakr.arabicwordformatter.databinding.FragmentDraftsBinding
import com.sakr.arabicwordformatter.domain.model.ParsedDocument
import com.sakr.arabicwordformatter.domain.usecase.ParseTextUseCase
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DraftsFragment : Fragment() {
    private var _binding: FragmentDraftsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DraftsViewModel by viewModels()
    private lateinit var adapter: DraftAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDraftsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeDrafts()

        binding.btnBack.setOnClickListener { findNavController().navigateUp() }
        binding.btnNewDocument.setOnClickListener { findNavController().navigateUp() }
    }

    private fun setupRecyclerView() {
        adapter = DraftAdapter(
            onDraftClick = { draft -> loadDraft(draft) },
            onDraftDelete = { draft -> confirmDelete(draft) }
        )
        binding.recyclerDrafts.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerDrafts.adapter = adapter
    }

    private fun observeDrafts() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.drafts.collectLatest { drafts ->
                    adapter.submitList(drafts)
                    binding.emptyView.visibility =
                        if (drafts.isEmpty()) View.VISIBLE else View.GONE
                    binding.recyclerDrafts.visibility =
                        if (drafts.isEmpty()) View.GONE else View.VISIBLE
                }
            }
        }
    }

    private fun loadDraft(draft: DraftEntity) {
        try {
            val parseUseCase = ParseTextUseCase()
            val document = ParsedDocument(
                blocks = parseUseCase(draft.rawText).blocks,
                title = draft.title,
                rawText = draft.rawText
            )
            val bundle = Bundle().apply {
                putSerializable("parsed_document", document)
            }
            findNavController().navigate(
                R.id.action_drafts_to_preview, bundle
            )
        } catch (e: Exception) {
            Snackbar.make(binding.root, "فشل تحميل المسودة", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(draft: DraftEntity) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("حذف مسودة")
            .setMessage("هل أنت متأكد من حذف هذه المسودة؟")
            .setPositiveButton("حذف") { _, _ ->
                viewModel.deleteDraft(draft)
                Snackbar.make(binding.root, "تم الحذف", Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class DraftAdapter(
    private val onDraftClick: (DraftEntity) -> Unit,
    private val onDraftDelete: (DraftEntity) -> Unit
) : ListAdapter<DraftEntity, DraftAdapter.ViewHolder>(DraftDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_draft, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleText: TextView = itemView.findViewById(R.id.textDraftTitle)
        private val dateText: TextView = itemView.findViewById(R.id.textDraftDate)
        private val previewText: TextView = itemView.findViewById(R.id.textDraftPreview)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btnDeleteDraft)

        fun bind(draft: DraftEntity) {
            titleText.text = draft.title.ifBlank { "بدون عنوان" }
            dateText.text = formatDate(draft.lastModified)
            previewText.text = draft.rawText.take(100) + if (draft.rawText.length > 100) "…" else ""
            itemView.setOnClickListener { onDraftClick(draft) }
            btnDelete.setOnClickListener { onDraftDelete(draft) }
        }

        private fun formatDate(timestamp: Long): String {
            val sdf = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale("ar"))
            return sdf.format(java.util.Date(timestamp))
        }
    }
}

class DraftDiffCallback : DiffUtil.ItemCallback<DraftEntity>() {
    override fun areItemsTheSame(oldItem: DraftEntity, newItem: DraftEntity): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: DraftEntity, newItem: DraftEntity): Boolean {
        return oldItem == newItem
    }
}
