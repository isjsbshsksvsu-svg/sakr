package com.sakr.arabicwordformatter.data.repository

import com.sakr.arabicwordformatter.data.db.DraftDao
import com.sakr.arabicwordformatter.data.db.DraftEntity
import kotlinx.coroutines.flow.Flow

class DraftRepository(private val draftDao: DraftDao) {

    val allDrafts: Flow<List<DraftEntity>> = draftDao.getAllDrafts()
    val allTemplates: Flow<List<DraftEntity>> = draftDao.getAllTemplates()

    suspend fun getDraftById(id: Int): DraftEntity? = draftDao.getDraftById(id)

    suspend fun saveDraft(title: String, rawText: String, type: String = "draft"): Long {
        val draft = DraftEntity(
            title = title,
            rawText = rawText,
            type = type,
            createdAt = System.currentTimeMillis(),
            lastModified = System.currentTimeMillis()
        )
        return draftDao.saveDraft(draft)
    }

    suspend fun updateDraft(draft: DraftEntity) {
        draftDao.saveDraft(draft.copy(lastModified = System.currentTimeMillis()))
    }

    suspend fun deleteDraft(id: Int) {
        draftDao.deleteDraftById(id)
    }
}
