package com.sakr.arabicwordformatter.domain.usecase

import android.content.Context
import android.net.Uri
import com.sakr.arabicwordformatter.core.docx.DocxBuilder
import com.sakr.arabicwordformatter.core.utils.FileHelper
import com.sakr.arabicwordformatter.domain.model.ParsedDocument

class GenerateDocxUseCase {
    private val docxBuilder = DocxBuilder()

    fun invoke(context: Context, document: ParsedDocument, fileName: String): Result<Uri> {
        return try {
            val doc = docxBuilder.build(document)
            val uri = FileHelper.saveDocx(context, doc, fileName)
            doc.close()
            if (uri != null) {
                Result.success(uri)
            } else {
                Result.failure(Exception("فشل حفظ الملف"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
