package com.sakr.arabicwordformatter.domain.usecase

import com.sakr.arabicwordformatter.core.parser.ArabicTextParser
import com.sakr.arabicwordformatter.domain.model.ParsedDocument

class ParseTextUseCase {
    private val parser = ArabicTextParser()

    operator fun invoke(rawText: String): ParsedDocument {
        if (rawText.isBlank()) {
            return ParsedDocument(blocks = emptyList(), title = null, rawText = rawText)
        }
        return parser.parse(rawText)
    }
}
