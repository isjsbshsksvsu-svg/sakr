package com.sakr.arabicwordformatter.presentation.drafts

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.sakr.arabicwordformatter.SakrApplication
import com.sakr.arabicwordformatter.data.db.DraftEntity
import kotlinx.coroutines.launch

class DraftsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as SakrApplication).draftRepository

    val drafts = repository.allDrafts

    private val _selectedDraft = MutableLiveData<DraftEntity?>()
    val selectedDraft: LiveData<DraftEntity?> = _selectedDraft

    fun deleteDraft(draft: DraftEntity) {
        viewModelScope.launch {
            repository.deleteDraft(draft.id)
        }
    }

    fun selectDraft(draft: DraftEntity) {
        _selectedDraft.value = draft
    }

    fun clearSelection() {
        _selectedDraft.value = null
    }
}
