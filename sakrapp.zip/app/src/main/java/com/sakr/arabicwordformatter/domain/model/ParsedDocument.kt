package com.sakr.arabicwordformatter.domain.model

import java.io.Serializable

data class ParsedDocument(
    val blocks: List<DocumentBlock>,
    val title: String? = null,
    val rawText: String = ""
) : Serializable {
    companion object {
        private const val serialVersionUID = 1L
    }
}
