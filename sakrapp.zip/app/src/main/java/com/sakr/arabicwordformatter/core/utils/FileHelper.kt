package com.sakr.arabicwordformatter.core.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.apache.poi.xwpf.usermodel.XWPFDocument
import java.io.File
import java.io.FileOutputStream

object FileHelper {

    fun saveDocx(context: Context, doc: XWPFDocument, fileName: String): Uri? {
        val safeFileName = sanitizeFileName(fileName)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveUsingMediaStore(context, doc, safeFileName)
        } else {
            saveUsingFileApi(context, doc, safeFileName)
        }
    }

    private fun saveUsingMediaStore(context: Context, doc: XWPFDocument, fileName: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "$fileName.docx")
            put(
                MediaStore.Downloads.MIME_TYPE,
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = context.contentResolver.insert(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
        )

        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    doc.write(stream)
                }
                // Mark as not pending
                val updateValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                context.contentResolver.update(it, updateValues, null, null)
            } catch (e: Exception) {
                // Clean up on failure
                context.contentResolver.delete(it, null, null)
                throw e
            }
        }
        return uri
    }

    private fun saveUsingFileApi(context: Context, doc: XWPFDocument, fileName: String): Uri? {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS
        )
        if (!downloadsDir.exists()) downloadsDir.mkdirs()

        val file = File(downloadsDir, "$fileName.docx")

        // Handle duplicate names
        var finalFile = file
        var counter = 1
        while (finalFile.exists()) {
            finalFile = File(downloadsDir, "${fileName}_$counter.docx")
            counter++
        }

        try {
            FileOutputStream(finalFile).use { doc.write(it) }
        } catch (e: Exception) {
            // Fallback to app-specific directory
            val appDir = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                fileName + ".docx"
            )
            FileOutputStream(appDir).use { doc.write(it) }
            return Uri.fromFile(appDir)
        }

        return Uri.fromFile(finalFile)
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[/\\\\:*?\"<>|]"), "_")
            .take(100)
            .ifBlank { "مستند_سكر" }
    }
}
