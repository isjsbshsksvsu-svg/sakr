package com.sakr.arabicwordformatter

import androidx.multidex.MultiDexApplication
import com.sakr.arabicwordformatter.data.db.AppDatabase
import com.sakr.arabicwordformatter.data.repository.DraftRepository

class SakrApplication : MultiDexApplication() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val draftRepository: DraftRepository by lazy {
        DraftRepository(database.draftDao())
    }
}
