package com.sakr.arabicwordformatter.presentation.input

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sakr.arabicwordformatter.domain.model.ParsedDocument
import com.sakr.arabicwordformatter.domain.usecase.ParseTextUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class InputViewModel : ViewModel() {
    private val parseTextUseCase = ParseTextUseCase()

    private val _rawText = MutableLiveData("")
    val rawText: LiveData<String> = _rawText

    private val _isProcessing = MutableLiveData(false)
    val isProcessing: LiveData<Boolean> = _isProcessing

    private val _parsedDocument = MutableLiveData<ParsedDocument?>()
    val parsedDocument: LiveData<ParsedDocument?> = _parsedDocument

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun setText(text: String) {
        _rawText.value = text
        _error.value = null
    }

    fun parseText() {
        val text = _rawText.value ?: ""
        if (text.isBlank()) {
            _error.value = "الرجاء إدخال نص أولاً"
            return
        }

        _isProcessing.value = true
        _error.value = null

        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                parseTextUseCase(text)
            }
            _parsedDocument.value = result
            _isProcessing.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }
}
