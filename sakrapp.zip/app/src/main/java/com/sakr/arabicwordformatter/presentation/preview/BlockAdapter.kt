package com.sakr.arabicwordformatter.presentation.preview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.sakr.arabicwordformatter.R
import com.sakr.arabicwordformatter.domain.model.DocumentBlock

class BlockAdapter(
    private val onBlockChanged: (Int, DocumentBlock) -> Unit,
    private val onDeleteBlock: (Int) -> Unit,
    private val onMergeBlock: (Int) -> Unit
) : RecyclerView.Adapter<BlockAdapter.BlockViewHolder>() {

    private var blocks: List<DocumentBlock> = emptyList()
    var onStartDrag: ((RecyclerView.ViewHolder) -> Unit)? = null

    fun submitList(newBlocks: List<DocumentBlock>) {
        val diffResult = DiffUtil.calculateDiff(BlockDiffCallback(blocks, newBlocks))
        blocks = newBlocks
        diffResult.dispatchUpdatesTo(this)
    }

    override fun getItemCount() = blocks.size

    override fun getItemViewType(position: Int): Int {
        return when (blocks[position]) {
            is DocumentBlock.MainHeading -> VIEW_TYPE_HEADING
            is DocumentBlock.SubHeading -> VIEW_TYPE_SUBHEADING
            is DocumentBlock.Paragraph -> VIEW_TYPE_PARAGRAPH
            is DocumentBlock.BulletList -> VIEW_TYPE_LIST
            is DocumentBlock.NumberedList -> VIEW_TYPE_LIST
            is DocumentBlock.ComparisonTable -> VIEW_TYPE_TABLE
            is DocumentBlock.Definition -> VIEW_TYPE_PARAGRAPH
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BlockViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_HEADING -> {
                val view = inflater.inflate(R.layout.item_block_heading, parent, false)
                HeadingViewHolder(view)
            }
            VIEW_TYPE_SUBHEADING -> {
                val view = inflater.inflate(R.layout.item_block_subheading, parent, false)
                SubHeadingViewHolder(view)
            }
            VIEW_TYPE_PARAGRAPH -> {
                val view = inflater.inflate(R.layout.item_block_paragraph, parent, false)
                ParagraphViewHolder(view)
            }
            VIEW_TYPE_LIST -> {
                val view = inflater.inflate(R.layout.item_block_list, parent, false)
                ListViewHolder(view)
            }
            VIEW_TYPE_TABLE -> {
                val view = inflater.inflate(R.layout.item_block_table, parent, false)
                TableViewHolder(view)
            }
            else -> throw IllegalArgumentException("Unknown view type: $viewType")
        }
    }

    override fun onBindViewHolder(holder: BlockViewHolder, position: Int) {
        holder.bind(blocks[position], position)
    }

    abstract inner class BlockViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        abstract fun bind(block: DocumentBlock, position: Int)

        protected fun setupActions(position: Int) {
            val chipGroup = itemView.findViewById<ChipGroup>(R.id.chipGroupBlockActions)
            if (chipGroup != null) {
                chipGroup.visibility = View.VISIBLE

                // Find or setup action chips
                val chipDelete = chipGroup.findViewById<Chip>(R.id.chipDelete)
                val chipHeading = chipGroup.findViewById<Chip>(R.id.chipHeading)
                val chipParagraph = chipGroup.findViewById<Chip>(R.id.chipParagraph)
                val chipMerge = chipGroup.findViewById<Chip>(R.id.chipMerge)

                chipDelete?.setOnClickListener { onDeleteBlock(position) }
                chipHeading?.setOnClickListener {
                    val block = blocks[position]
                    val newBlock = when (block) {
                        is DocumentBlock.Paragraph -> DocumentBlock.MainHeading(block.text)
                        is DocumentBlock.BulletList -> DocumentBlock.MainHeading(
                            block.items.joinToString("\n")
                        )
                        else -> block
                    }
                    if (newBlock != block) onBlockChanged(position, newBlock)
                }
                chipParagraph?.setOnClickListener {
                    val block = blocks[position]
                    val newBlock = when (block) {
                        is DocumentBlock.MainHeading -> DocumentBlock.Paragraph(block.text)
                        is DocumentBlock.SubHeading -> DocumentBlock.Paragraph(block.text)
                        is DocumentBlock.BulletList -> DocumentBlock.Paragraph(
                            block.items.joinToString("\n")
                        )
                        else -> block
                    }
                    if (newBlock != block) onBlockChanged(position, newBlock)
                }
                chipMerge?.setOnClickListener { onMergeBlock(position) }
            }
        }
    }

    inner class HeadingViewHolder(itemView: View) : BlockViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(R.id.textHeading)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardBlock)

        override fun bind(block: DocumentBlock, position: Int) {
            if (block is DocumentBlock.MainHeading) {
                textView.text = block.text
                cardView.contentDescription = "عنوان رئيسي: ${block.text}"
            }
            setupActions(position)
        }
    }

    inner class SubHeadingViewHolder(itemView: View) : BlockViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(R.id.textSubHeading)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardBlock)

        override fun bind(block: DocumentBlock, position: Int) {
            if (block is DocumentBlock.SubHeading) {
                textView.text = block.text
                cardView.contentDescription = "عنوان فرعي: ${block.text}"
            }
            setupActions(position)
        }
    }

    inner class ParagraphViewHolder(itemView: View) : BlockViewHolder(itemView) {
        private val editText: EditText = itemView.findViewById(R.id.editParagraph)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardBlock)

        override fun bind(block: DocumentBlock, position: Int) {
            if (block is DocumentBlock.Paragraph) {
                // Prevent infinite loop
                if (editText.text?.toString() != block.text) {
                    editText.setText(block.text)
                }
                editText.doAfterTextChanged { editable ->
                    val newText = editable?.toString() ?: ""
                    if (newText != block.text) {
                        onBlockChanged(position, DocumentBlock.Paragraph(newText))
                    }
                }
                cardView.contentDescription = "فقرة"
            } else if (block is DocumentBlock.Definition) {
                if (editText.text?.toString() != "${block.term}: ${block.meaning}") {
                    editText.setText("${block.term}: ${block.meaning}")
                }
                cardView.contentDescription = "تعريف"
            }
            setupActions(position)
        }
    }

    inner class ListViewHolder(itemView: View) : BlockViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(R.id.textListContent)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardBlock)

        override fun bind(block: DocumentBlock, position: Int) {
            val content = when (block) {
                is DocumentBlock.BulletList -> block.items.joinToString("\n") { "• $it" }
                is DocumentBlock.NumberedList -> block.items.mapIndexed { i, s -> "${i + 1}. $s" }
                    .joinToString("\n")
                else -> ""
            }
            textView.text = content
            cardView.contentDescription = "قائمة"
            setupActions(position)
        }
    }

    inner class TableViewHolder(itemView: View) : BlockViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(R.id.textTablePreview)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardBlock)

        override fun bind(block: DocumentBlock, position: Int) {
            if (block is DocumentBlock.ComparisonTable) {
                val sb = StringBuilder()
                sb.appendLine("جدول: ${block.headers.joinToString(" | ")}")
                block.rows.forEach { row ->
                    sb.appendLine(row.joinToString(" | "))
                }
                textView.text = sb.toString()
                cardView.contentDescription = "جدول مقارنة"
            }
            setupActions(position)
        }
    }

    companion object {
        const val VIEW_TYPE_HEADING = 0
        const val VIEW_TYPE_SUBHEADING = 1
        const val VIEW_TYPE_PARAGRAPH = 2
        const val VIEW_TYPE_LIST = 3
        const val VIEW_TYPE_TABLE = 4
    }
}

class BlockDiffCallback(
    private val oldList: List<DocumentBlock>,
    private val newList: List<DocumentBlock>
) : DiffUtil.Callback() {
    override fun getOldListSize() = oldList.size
    override fun getNewListSize() = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val old = oldList[oldItemPosition]
        val new = newList[newItemPosition]
        return old.javaClass == new.javaClass &&
               old.toEditableText() == new.toEditableText()
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition] == newList[newItemPosition]
    }
}
