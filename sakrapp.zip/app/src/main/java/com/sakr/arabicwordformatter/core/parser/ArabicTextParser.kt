package com.sakr.arabicwordformatter.core.parser

import com.sakr.arabicwordformatter.domain.model.DocumentBlock
import com.sakr.arabicwordformatter.domain.model.ParsedDocument

class ArabicTextParser {

    fun parse(rawText: String): ParsedDocument {
        val lines = rawText.split("\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val blocks = mutableListOf<DocumentBlock>()
        var i = 0

        while (i < lines.size) {
            val line = lines[i]
            val trimmedLine = cleanLine(line)

            when {
                // Check for comparison table first (multi-line)
                isComparisonStart(line, i, lines) -> {
                    val result = buildComparisonTable(lines, i)
                    blocks.add(result.first)
                    i = result.second
                }
                // Main heading
                isMainHeading(line, lines, i) -> {
                    blocks.add(DocumentBlock.MainHeading(trimmedLine))
                }
                // Sub heading
                isSubHeading(line) -> {
                    blocks.add(DocumentBlock.SubHeading(trimmedLine))
                }
                // List items (collect consecutive items)
                isListItem(line) -> {
                    val result = collectListItems(lines, i)
                    blocks.addAll(result.first)
                    i = result.second
                }
                // Definition
                isDefinition(line) -> {
                    val (term, meaning) = parseDefinition(line)
                    blocks.add(DocumentBlock.Definition(term, meaning))
                }
                // Regular paragraph
                else -> {
                    blocks.add(DocumentBlock.Paragraph(trimmedLine))
                }
            }
            i++
        }

        val title = detectTitle(lines)
        return ParsedDocument(
            blocks = blocks,
            title = title,
            rawText = rawText
        )
    }

    /**
     * Detects a main title for the document from the first meaningful line.
     */
    private fun detectTitle(lines: List<String>): String? {
        if (lines.isEmpty()) return null
        val firstLine = lines.first().trim()
        // First line could be a title if it's short enough and isn't a list item
        return if (firstLine.length < PatternRules.SHORT_HEADING_THRESHOLD
            && !isListItem(firstLine)
            && !firstLine.contains(":")
        ) firstLine else null
    }

    /**
     * Improved main heading detection using contextual clues.
     */
    private fun isMainHeading(line: String, allLines: List<String>, index: Int): Boolean {
        val trimmed = line.trim()
        if (trimmed.length > PatternRules.SHORT_HEADING_THRESHOLD) return false
        if (trimmed.contains(":")) return false
        if (isListItem(trimmed)) return false
        if (isSubHeading(trimmed)) return false

        // First line is often a heading
        if (index == 0 && trimmed.length < 60) return true

        // Short line (1-4 words) that doesn't end with punctuation
        val wordCount = trimmed.split("\\s+".toRegex()).size
        if (wordCount in 1..6) {
            // Check it's not part of a list
            if (allLines.indices.any { i ->
                    i != index && isListItem(allLines[i]) && allLines[i].contains(trimmed)
                }) return false
            return true
        }

        return false
    }

    /**
     * Detects subheadings: numbered prefixes, ordinal words, or colon endings.
     */
    internal fun isSubHeading(line: String): Boolean {
        val trimmed = line.trim()
        // Ordinal-based subheadings
        if (PatternRules.ARABIC_ORDINALS.any { trimmed.startsWith(it) }) return true

        // Numbered subheadings (e.g., "1. المقدمة", "١- الباب الأول")
        if (trimmed.matches(Regex("^[\\d٠١٢٣٤٥٦٧٨٩]+[-.)]\\s*.+"))) {
            // Differentiate from numbered list items (lists are shorter, items not headers)
            return true
        }

        // Colon-ending lines are usually subheadings
        if (trimmed.endsWith(":") && trimmed.length < 60) return true

        return false
    }

    /**
     * Detects list items (bullets or numbered).
     */
    internal fun isListItem(line: String): Boolean {
        val trimmed = line.trim()
        // Bullet points
        if (PatternRules.BULLET_PATTERN.matches(trimmed)) return true
        // Numbered items
        if (PatternRules.NUMBERED_PATTERN.matches(trimmed)) return true
        return false
    }

    /**
     * Collects consecutive list items into a single list block.
     */
    private fun collectListItems(lines: List<String>, startIndex: Int): Pair<List<DocumentBlock>, Int> {
        val bullets = mutableListOf<String>()
        val numbers = mutableListOf<String>()
        var isNumbered: Boolean? = null
        var i = startIndex

        while (i < lines.size && isListItem(lines[i])) {
            val line = lines[i].trim()
            val content = line
                .replace(PatternRules.BULLET_PATTERN, "")
                .replace(PatternRules.NUMBERED_PATTERN, "")
                .trim()

            val currentIsNumbered = PatternRules.NUMBERED_PATTERN.matches(line)
            if (isNumbered == null) {
                isNumbered = currentIsNumbered
            }

            if (isNumbered) {
                numbers.add(content)
            } else {
                bullets.add(content)
            }
            i++
        }

        return if (isNumbered == true) {
            listOf(DocumentBlock.NumberedList(numbers)) to (i - 1)
        } else {
            listOf(DocumentBlock.BulletList(bullets)) to (i - 1)
        }
    }

    /**
     * Checks if a line starts a comparison table.
     */
    private fun isComparisonStart(line: String, index: Int, lines: List<String>): Boolean {
        val trimmed = line.trim()
        // Direct comparison keywords
        if (PatternRules.COMPARISON_KEYWORDS.any { trimmed.contains(it) }) return true
        // "vs" pattern
        if (trimmed.contains(" vs ") || trimmed.contains(" VS ")) return true
        // Next line contains "/" separator (comparison pattern)
        if (index < lines.size - 1 && lines[index + 1].contains("/")) return true
        return false
    }

    /**
     * Builds a comparison table from consecutive table-like lines.
     */
    private fun buildComparisonTable(lines: List<String>, startIndex: Int): Pair<DocumentBlock.ComparisonTable, Int> {
        val headerLine = cleanLine(lines[startIndex])
        val headers = parseHeaders(headerLine)
        val rows = mutableListOf<List<String>>()
        var i = startIndex + 1

        while (i < lines.size && isTableRow(lines[i])) {
            val rowContent = lines[i].trim()
            val cells = rowContent.split("/")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            if (cells.isNotEmpty()) {
                rows.add(cells)
            }
            i++
        }

        val allHeaders = if (headers.isEmpty()) {
            // Try to extract headers from row 0
            if (rows.isNotEmpty()) {
                val firstRow = rows.removeAt(0)
                firstRow
            } else emptyList()
        } else headers

        return DocumentBlock.ComparisonTable(allHeaders, rows, rows.size) to (i - 1)
    }

    /**
     * Parses header line (e.g., "الفرق بين الخلية النباتية والحيوانية").
     */
    private fun parseHeaders(line: String): List<String> {
        // Extract comparison subjects from "الفرق بين X و Y" pattern
        val match = Regex("الفرق\\s+بين\\s+(.+?)\\s+و\\s+(.+)").find(line)
        if (match != null) {
            return listOf(match.groupValues[1].trim(), match.groupValues[2].trim())
        }
        // "مقارنة بين X و Y"
        val match2 = Regex("مقارنة\\s+بين\\s+(.+?)\\s+و\\s+(.+)").find(line)
        if (match2 != null) {
            return listOf(match2.groupValues[1].trim(), match2.groupValues[2].trim())
        }
        // Generic table: split on comparison keywords
        return emptyList()
    }

    /**
     * Checks if a line is part of a table (contains "/" separator).
     */
    private fun isTableRow(line: String): Boolean {
        return line.trim().contains("/") && !line.trim().startsWith("الفرق") &&
               !line.trim().startsWith("مقارنة")
    }

    /**
     * Checks if a line is a definition (contains definition keywords).
     */
    private fun isDefinition(line: String): Boolean {
        val trimmed = line.trim()
        return PatternRules.DEFINITION_KEYWORDS.any { keyword ->
            trimmed.contains(keyword) && !trimmed.startsWith("-") && !trimmed.startsWith("•")
        }
    }

    /**
     * Parses a definition line into term and meaning.
     */
    private fun parseDefinition(line: String): Pair<String, String> {
        val trimmed = line.trim()
        // Try splitting on definition keywords
        for (keyword in PatternRules.DEFINITION_KEYWORDS) {
            val index = trimmed.indexOf(keyword)
            if (index > 0) {
                val term = trimmed.substring(0, index).trim()
                val meaning = trimmed.substring(index).trim()
                return term to meaning
            }
        }
        // Fallback: split on ":"
        val colonIndex = trimmed.indexOf(":")
        if (colonIndex > 0) {
            return trimmed.substring(0, colonIndex).trim() to
                    trimmed.substring(colonIndex + 1).trim()
        }
        return trimmed to ""
    }

    /**
     * Cleans a line of text for display.
     */
    fun cleanLine(line: String): String {
        return line.trim()
            .replace(Regex("\\s+"), " ")  // Normalize whitespace
            .trim()
    }
}
