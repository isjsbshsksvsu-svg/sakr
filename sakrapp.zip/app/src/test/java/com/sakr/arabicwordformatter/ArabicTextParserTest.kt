package com.sakr.arabicwordformatter

import com.sakr.arabicwordformatter.core.parser.ArabicTextParser
import com.sakr.arabicwordformatter.domain.model.DocumentBlock
import org.junit.Assert.*
import org.junit.Test

class ArabicTextParserTest {

    private val parser = ArabicTextParser()

    @Test
    fun `heading detection works for short Arabic lines`() {
        val result = parser.parse("الخلية\nالخلية هي وحدة البناء الأساسية")
        assertTrue("First block should be MainHeading", result.blocks[0] is DocumentBlock.MainHeading)
        assertTrue("Second block should be Paragraph", result.blocks[1] is DocumentBlock.Paragraph)
    }

    @Test
    fun `subheading detection with ordinal`() {
        val result = parser.parse("أولاً: المقدمة\nهذا هو النص التمهيدي")
        assertTrue(result.blocks[0] is DocumentBlock.SubHeading)
    }

    @Test
    fun `subheading with colon`() {
        val result = parser.parse("أنواع الخلايا:")
        assertTrue(result.blocks[0] is DocumentBlock.SubHeading)
    }

    @Test
    fun `bullet list detection`() {
        val result = parser.parse("- عنصر أول\n- عنصر ثانٍ\n- عنصر ثالث")
        assertEquals(1, result.blocks.size)
        assertTrue(result.blocks[0] is DocumentBlock.BulletList)
        assertEquals(3, (result.blocks[0] as DocumentBlock.BulletList).items.size)
    }

    @Test
    fun `numbered list detection`() {
        val result = parser.parse("1. أولاً\n2. ثانياً\n3. ثالثاً")
        assertEquals(1, result.blocks.size)
        assertTrue(result.blocks[0] is DocumentBlock.NumberedList)
    }

    @Test
    fun `comparison keyword triggers table`() {
        val input = "الفرق بين الخلية النباتية والحيوانية\nالنباتية / الحيوانية\nفيها جدار خلوي / ليس فيها جدار"
        val result = parser.parse(input)
        assertTrue("Should detect comparison table", result.blocks.any { it is DocumentBlock.ComparisonTable })
    }

    @Test
    fun `definition detection`() {
        val result = parser.parse("الخلية هي وحدة البناء الأساسية للكائن الحي")
        assertTrue(result.blocks[0] is DocumentBlock.Definition)
        val def = result.blocks[0] as DocumentBlock.Definition
        assertEquals("الخلية", def.term)
        assertTrue(def.meaning.contains("وحدة البناء"))
    }

    @Test
    fun `title detection from first line`() {
        val result = parser.parse("مكونات الخلية\nالخلية لها أجزاء متعددة")
        assertEquals("مكونات الخلية", result.title)
    }

    @Test
    fun `empty input returns empty document`() {
        val result = parser.parse("")
        assertTrue(result.blocks.isEmpty())
    }

    @Test
    fun `mixed content parsing`() {
        val input = """
            أنواع الخلايا
            هناك عدة أنواع من الخلايا في الكائن الحي.
            أولاً: الخلية النباتية
            - لها جدار خلوي
            - فيها بلاستيدات
            ثانياً: الخلية الحيوانية
            - ليس لها جدار خلوي
            - فيها مريكزات
            الفرق بين الخلية النباتية والحيوانية
            النباتية / الحيوانية
            لها جدار / ليس لها جدار
        """.trimIndent()

        val result = parser.parse(input)
        assertTrue(result.blocks.isNotEmpty())
        assertTrue(result.blocks.any { it is DocumentBlock.MainHeading })
        assertTrue(result.blocks.any { it is DocumentBlock.SubHeading })
        assertTrue(result.blocks.any { it is DocumentBlock.BulletList })
        assertTrue(result.blocks.any { it is DocumentBlock.Paragraph })
    }
}
