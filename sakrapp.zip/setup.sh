#!/bin/bash
# ============================================================
# Sakr - Script تجهيز المشروع للبناء
# ============================================================
# يعمل على Linux/macOS
# Requirements: Java 17+ (JDK)

set -e

echo "🔧 Sakr - تجهيز بيئة البناء"
echo "================================"

# 1. التأكد من Java
if ! command -v java &> /dev/null; then
    echo "❌ Java غير موجود. الرجاء تثبيت JDK 17+"
    echo "   https://adoptium.net/"
    exit 1
fi

JAVA_VER=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VER" -lt 17 ]; then
    echo "❌ Java 17+ مطلوب. الإصدار الحالي: $(java -version 2>&1 | head -1)"
    exit 1
fi
echo "✅ Java: $(java -version 2>&1 | head -1)"

# 2. إنشاء Gradle Wrapper
echo "📦 إنشاء Gradle Wrapper..."
if [ ! -f "gradlew" ]; then
    # نبحث عن Gradle مثبت أو ننزل الـ wrapper jar يدوياً
    if command -v gradle &> /dev/null; then
        gradle wrapper --gradle-version=8.7
    else
        echo "📥 تحميل Gradle Wrapper..."
        # تحميل الـ wrapper jar من Maven Central
        WRAPPER_VERSION="8.7"
        mkdir -p gradle/wrapper
        
        # Download gradle-wrapper.jar
        curl -sL "https://services.gradle.org/distributions/gradle-${WRAPPER_VERSION}-bin.zip" -o /tmp/gradle-bin.zip
        unzip -q /tmp/gradle-bin.zip -d /tmp/gradle-temp
        cp /tmp/gradle-temp/gradle-${WRAPPER_VERSION}/lib/gradle-wrapper-*.jar gradle/wrapper/gradle-wrapper.jar 2>/dev/null || true
        rm -rf /tmp/gradle-temp /tmp/gradle-bin.zip
        
        # Create gradlew script
        cat > gradlew << 'GRADLEW'
#!/bin/sh
# Gradle wrapper script

# Determine the project base dir
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Add default JVM options here
DEFAULT_JVM_OPTS='"-Xmx64m" "-Xms64m"'

APP_NAME="Gradle"
APP_BASE_NAME=$(basename "$0")

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar

# Determine the Java command to use
if [ -n "$JAVA_HOME" ] ; then
    JAVACMD="$JAVA_HOME/bin/java"
else
    JAVACMD="java"
fi

exec "$JAVACMD" \
    $DEFAULT_JVM_OPTS \
    $JAVA_OPTS \
    $GRADLE_OPTS \
    "-Dorg.gradle.appname=$APP_BASE_NAME" \
    -classpath "$CLASSPATH" \
    org.gradle.wrapper.GradleWrapperMain "$@"
GRADLEW
        chmod +x gradlew
        echo "   تم إنشاء gradlew"
    fi
else
    echo "✅ gradlew موجود"
fi

# 3. تأكيد صلاحيات التنفيذ
chmod +x gradlew 2>/dev/null || true

# 4. بناء المشروع
echo ""
echo "================================"
echo "🚀 كل شيء جاهز!"
echo ""
echo "  للبناء Debug APK:"
echo "    ./gradlew assembleDebug"
echo ""
echo "  للبناء Release APK:"
echo "    ./gradlew assembleRelease"
echo ""
echo "  الـ APK会在:"
echo "    app/build/outputs/apk/debug/"
echo "    app/build/outputs/apk/release/"
echo "================================"
